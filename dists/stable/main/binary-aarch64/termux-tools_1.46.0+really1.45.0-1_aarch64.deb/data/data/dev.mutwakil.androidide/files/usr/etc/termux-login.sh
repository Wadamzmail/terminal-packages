##
## This script is sourced by /data/data/dev.mutwakil.androidide/files/usr/bin/login before executing shell.
##
