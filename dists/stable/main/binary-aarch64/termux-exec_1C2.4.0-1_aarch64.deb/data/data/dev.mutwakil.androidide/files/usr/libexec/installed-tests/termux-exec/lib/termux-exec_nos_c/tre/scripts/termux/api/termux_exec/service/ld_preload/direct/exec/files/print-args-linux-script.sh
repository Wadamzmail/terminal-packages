#!/data/data/dev.mutwakil.androidide/files/usr/bin/sh

echo "$@"
