# 3rd party completion loader for commands emitting their completion using
# "$cmd completion --bash".
#
# For example, pip uses this form of dynamic completions.
#
# This serves as a fallback in case the completion is not installed otherwise.

eval -- "$("$1" completion --bash 2>/dev/null)"
